import 'package:flutter/material.dart';
import 'package:flutter_app_cadastro/tela_dados_cadastrais.dart';
import 'package:flutter_app_cadastro/tela_submeter_docs.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // Esse é o widget root da aplicação
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LIIde',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      //home: DadosCadastrais(),
      routes: <String, WidgetBuilder>{
        'tela1': (BuildContext context) => new DadosCadastrais(),
        'tela2': (BuildContext context) => new UploadImageApp()
      },
      initialRoute: 'tela1',
    );
  }
}
