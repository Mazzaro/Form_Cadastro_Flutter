
import 'package:flutter/material.dart';

class DadosCadastrais extends StatefulWidget {
  @override
  _DadosCadastraisState createState() => _DadosCadastraisState();
}

class _DadosCadastraisState extends State<DadosCadastrais> {

  //Método onChanged do Radio Button. Precisa ser implementado para o botão funcionar como deve.
  int _radioValue1 = -1;
  void _ChangeRadioValue(int value) {
    setState(() {
      _radioValue1 = value;

    });

  }

  void _chamarTelaUpload(){
    Navigator.pushNamed(context, 'tela2');
  }

  // Variável que capitura o select do checkbox
  bool _select = false;

  // Stepper vai começar aqui
  int _currentStep = 0;

  List<Step> _mySteps(){
    List<Step> _steps = [
      Step(
        title: Text('Dados Pessoais'),
        content: Container(
          alignment: Alignment.center,
          margin: EdgeInsets.only(top: 5),
          width: MediaQuery.of(context).size.width/1.2,
          height: 310,
          padding: EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 2),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20)),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.deepPurple,
                    blurRadius: 5
                )//BoxShadow
              ]
          ),//BoxDecoration
          child: SingleChildScrollView(

            child : ListBody(
              children: <Widget>[

                // Input do Nome
                TextField(
                  decoration: InputDecoration(
                    icon: Icon(Icons.person),
                    hintText: 'Nome'
                  ), //InputDecoration
                ), //TextField

//               //Input do Sobrenome
                TextField(
                  decoration: InputDecoration(
                      icon: Icon(Icons.person),
                      hintText: 'Sobrenome'
                  ), //InputDecoration
                ), //TextField

                // Input do CPF
                TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                      icon: Icon(Icons.credit_card),
                      hintText: 'CPF'
                  ), //InputDecoration
                ), //TextField

                // Input do RG
                TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    icon: Icon(Icons.fingerprint),
                    hintText: 'RG',
                  ), //InputDecoration
                ), //TextField

                //Input da Data de nascimento
                TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                      icon: Icon(Icons.calendar_today),
                      hintText: 'dd/mm/aaaa '
                  ), //InputDecoration
                ), //TextField

                // Input da Naturalidade
                TextField(
                  decoration: InputDecoration(
                      icon: Icon(Icons.nature_people),
                      hintText: 'Naturalidade'
                  ), //InputDecoration
                ), //TextField

                // Input da Nacionalidade
                TextField(
                  decoration: InputDecoration(
                      icon: Icon(Icons.map),
                      hintText: 'Nacionalidade'
                  ), //InputDecoration
                ), //TextField

              ], //<Widget>[]
            ), //ListBody
          ),
        ),
        isActive: _currentStep >= 0,
      ), //Step
      Step(
        title: Text('Sexo'),
        content: Container(
            alignment: Alignment.center,
            margin: EdgeInsets.only(top: 5),
            width: MediaQuery.of(context).size.width/1.2,
            height: 150,
            padding: EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 2),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                      color: Colors.deepPurple,
                      blurRadius: 5
                  )//BoxShadow
                ]
            ),//BoxDecoration,
            child: SingleChildScrollView(
              child : ListBody(
                children: <Widget>[
                  Row(
                      children: <Widget>[
                        Radio(value: 0, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                        Text('Masculino', style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969),)
                        )
                      ]
                  ),
                  Row(
                      children: <Widget>[
                        Radio(value: 1, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                        Text('Feminino', style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                        )
                      ]
                  ),
                  Row(
                      children: <Widget>[
                        Radio(value: 2, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                        Text('Outro', style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                        )
                      ]
                  ),

                ],
              ),//ListBody
            ) //SingleChildScrollView

        ),
        isActive: _currentStep >= 1,
      ),
      Step(
        title: Text('Estado Civil'),
        content: Container(
            alignment: Alignment.center,
          margin: EdgeInsets.only(top: 5),
          width: MediaQuery.of(context).size.width/1.2,
          height: 300,
          padding: EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20)),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.deepPurple,
                blurRadius: 5
              )//BoxShadow
            ]
          ),//BoxDecoration,
          child: SingleChildScrollView(
            child : ListBody(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Radio(value: 0, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                    Text('Solteiro(a)', style: TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969),)
                    )
                  ]
                ),
                Row(
                  children: <Widget>[
                    Radio(value: 1, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                    Text('União Estável', style: TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                    )
                  ]
                ),
                Row(
                    children: <Widget>[
                      Radio(value: 2, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                      Text('Casado(a)', style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                      )
                    ]
                ),
                Row(
                    children: <Widget>[
                      Radio(value: 3, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                      Text('Separado(a)', style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                      )
                    ]
                ),
                Row(
                    children: <Widget>[
                      Radio(value: 4, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                      Text('Divorciado(a)', style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                      )
                    ]
                ),
                Row(
                    children: <Widget>[
                      Radio(value: 5, groupValue: _radioValue1, onChanged: _ChangeRadioValue),
                      Text('Viúvo(a)', style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF696969))
                      )
                    ]
                ),

              ],
            ),//ListBody
          ) //SingleChildScrollView

      ),
      isActive: _currentStep >= 2,
      ),
      Step(
        title: Text('Endereço'),
        content: Container(
          alignment: Alignment.center,
          margin: EdgeInsets.only(top: 5),
          width: MediaQuery.of(context).size.width/1.2,
          height: 285,
          padding: EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20)),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.deepPurple,
                blurRadius: 5
              )//BoxShadow
            ]
          ),//BoxDecoration
         child: SingleChildScrollView(
           child : ListBody(
            children: <Widget>[

              // Input do Logradouro
              TextField(
                decoration: InputDecoration(
                  icon: Icon(Icons.streetview),
                  hintText: 'Logradouro'
                ), //InputDecoration
              ), //TextField


              // Input do número da residência
              TextField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  icon: Icon(Icons.home),
                  hintText: 'Nº da residência'
                ), //InputDecoration
              ), //TextField

              // Input do CEP
              TextField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  icon: Icon(Icons.map),
                  hintText: 'CEP',
                ), //InputDecoration
              ), //TextField

              //Input do Bairro
              TextField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  icon: Icon(Icons.location_on),
                  hintText: 'Bairro'
                ), //InputDecoration
              ), //TextField

              //Input da Cidade
              TextField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    icon: Icon(Icons.location_city),
                    hintText: 'Cidade'
                ), //InputDecoration
              ), //TextField

              //Input do Estado
              TextField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    icon: Icon(Icons.domain),
                    hintText: 'Estado'
                ), //InputDecoration
              ), //TextField

            ], //<Widget>[]
           ), //ListBody
         ),
        ),
        isActive: _currentStep >= 3,
      ),
      Step(
        title: Text('Estamos quase lá!'),
        content: Container(
          alignment: Alignment.center,
          margin: EdgeInsets.only(top: 5),
          width: MediaQuery.of(context).size.width/1.2,
          height: 190,
          padding: EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 2),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20)),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.deepPurple,
                    blurRadius: 5
                )//BoxShadow
              ]
          ),//BoxDecoration
          child: SingleChildScrollView(
            child : ListBody(
              children: <Widget>[

                // Input do Telefone
                TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                      icon: Icon(Icons.phone_android),
                      hintText: 'Telefone'
                  ), //InputDecoration
                ), //TextField


                // Input do número do e-mail
                TextField(
                  decoration: InputDecoration(
                      icon: Icon(Icons.email),
                      hintText: 'E-mail'
                  ), //InputDecoration
                ), //TextField

                // Input da Senha
                TextField(
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    icon: Icon(Icons.lock_outline),
                    hintText: 'Senha',
                  ), //InputDecoration
                ), //TextField

                // Input da Confirmação de Senha
                TextField(
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    icon: Icon(Icons.lock),
                    hintText: 'Confirmar senha',
                  ), //InputDecoration
                ), //TextField

//                //Input do Bairro
//                TextField(
//                  keyboardType: TextInputType.number,
//                  decoration: InputDecoration(
//                      icon: Icon(Icons.location_city),
//                      hintText: 'Bairro'
//                  ), //InputDecoration
//                ), //TextField

              ], //<Widget>[]
            ), //ListBody
          ),
        ),
        isActive: _currentStep >= 4,
      ),

      Step(
        title: Text('Ultimos detalhes'),
        content: Container(
          alignment: Alignment.center,
          margin: EdgeInsets.only(top: 5),
          width: MediaQuery.of(context).size.width/1.2,
          height: 190,
          padding: EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 2),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20)),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.deepPurple,
                    blurRadius: 5
                )//BoxShadow
              ]
          ),//BoxDecoration
          child: SingleChildScrollView(
            child : ListBody(
              children: <Widget>[

                //Checkbox dos termos de uso
                CheckboxListTile(
                    title: Text('Declaro que li os trermos de uso e concordo'),
                    activeColor: Colors.deepPurple,
                    onChanged: (bool resp){
                      setState(() {
                        _select = resp;
                      });
                    },
                    value: _select,
                ),

                Container(
                  margin: EdgeInsets.only(top: 20),
                  height: 40,
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      stops: [0.3, 1],
                      colors: [
                        Color(0xFF4d3e7d),
                        Color(0xFF352b58),
                      ]
                    ),// Linear gradient
                    borderRadius: BorderRadius.all(
                      Radius.circular(5),
                    )// BorderRadius
                  ), // BoxDecoration
                  child: SizedBox.expand(
                    child: FlatButton(
                      child: Row(
                        children: <Widget>[
                          Text('Submeter Anexos', style: TextStyle(color: Colors.white),)
                        ], //<Widget>[]
                      ), //Row
                      onPressed: _chamarTelaUpload,
                    ),// FlatButtom
                  ),

                ), //Container

              ], //<Widget>[]
            ), //ListBody
          ),
        ),
        isActive: _currentStep >= 5,
      ),

    ];
    return _steps;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //body : Container()
      //resizeToAvoidBottomPadding: false,
      //resizeToAvoidBottomInset: false,
      body : Container (

        child: SingleChildScrollView(
         child : Column (
        children: <Widget>[

         Container(
         width: MediaQuery.of(context).size.width,
        height: 100,//MediaQuery.of(context).size.height/4,
        margin: EdgeInsets.only(top: 24, left: 10, right: 10),
        decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF352b58),
                Color(0xFF4d3e7d)
              ],
            ), //LinearGradient
            borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(15),
                bottomRight: Radius.circular(15),
                topRight: Radius.circular(15),
                topLeft: Radius.circular(15)
            )//borderRadius
        ), //BoxDecoration
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Spacer(),
            Align(
              alignment: Alignment.center,
              child: Icon(Icons.people,
                //child: Image.asset('imagens/logo.png'),
                size: 50,
                color: Colors.white,
              ),//Icon
            ),//Align

            Spacer(),

            Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: EdgeInsets.only(right: 32, bottom: 12),
                child: Text('Cadastro de Usuário', style: TextStyle(
                    color: Colors.white, fontSize: 20
                ),),
              ),//Padding
            ),//Align
          ],//<Widget>[]
        ),//Column
      ),

      SingleChildScrollView(

            child: Container(
              margin: EdgeInsets.only(top: 10, bottom: 10, left: 10, right: 10),
              height: MediaQuery.of(context).size.height/1.321,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                      topRight: Radius.circular(15),
                      topLeft: Radius.circular(15)
                  ),//borderRadius
                  color: Colors.white,
                  boxShadow: [
                  BoxShadow(
                  color: Colors.deepPurple,
                  blurRadius: 5
              )//BoxShadow
                ]
              ), //BoxDecoration

          child : Stepper(
          steps: _mySteps(),
          currentStep: this._currentStep,
          onStepTapped: (step){
            setState(() {
              this._currentStep = step;

            });
          },
          onStepContinue: (){
            setState(() {
              if(this._currentStep < this._mySteps().length - 1){
                this._currentStep = this._currentStep + 1;
              }
              else{
                //Codigo que verifica se os campos foram preenchidos
              }
            });
          },
          onStepCancel: (){
            setState(() {
              if(this._currentStep > 0){
                this._currentStep = this._currentStep -1;
              }
              else{
                this._currentStep = 0;
              }
            });
          },
        ),//Stepper
            )
          )
      ]
    )
        )
      )

    );//Scaffold

  // Stepper termina aqui

  }
}
